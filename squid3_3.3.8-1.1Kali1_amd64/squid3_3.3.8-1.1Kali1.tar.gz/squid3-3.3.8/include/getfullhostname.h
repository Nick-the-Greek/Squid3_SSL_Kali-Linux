#ifndef _SQUID_GETFULLHOSTNAME_H
#define _SQUID_GETFULLHOSTNAME_H

SQUIDCEXTERN const char *getfullhostname(void);

#endif /* _SQUID_GETFULLHOSTNAME_H */
