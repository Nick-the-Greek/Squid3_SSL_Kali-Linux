// 2008-05-14: rename to radius-util.* to avoid name clashes with squid util.*

// uses the squid utilities
#include "util.h"

/* util.c */
uint32_t		get_ipaddr (char *);
