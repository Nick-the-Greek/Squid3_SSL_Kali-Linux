extern char * get_nis_password(char *user, char *nisdomain, char *nismap);
