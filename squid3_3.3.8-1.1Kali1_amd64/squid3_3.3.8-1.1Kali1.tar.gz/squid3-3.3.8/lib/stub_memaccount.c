/* Stub function for programs not implementing statMemoryAccounted */
#include "squid.h"
#include "util.h"
int
statMemoryAccounted(void)
{
    return -1;
}
