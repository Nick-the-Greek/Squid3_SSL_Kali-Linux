#!/usr/bin/perl

$|=1;
while (<>) {
	print "OK\n";
}
print STDERR "stdin closed, exit\n";
