#include "squid.h"

#define STUB_API "mime.cc"
#include "tests/STUB.h"

size_t headersEnd(const char *mime, size_t l) STUB_RETVAL(0)
