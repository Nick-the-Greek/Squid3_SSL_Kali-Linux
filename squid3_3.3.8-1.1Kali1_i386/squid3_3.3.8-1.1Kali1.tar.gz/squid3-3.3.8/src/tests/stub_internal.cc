#include "squid.h"

#define STUB_API "internal.cc"
#include "tests/STUB.h"

char * internalLocalUri(const char *dir, const char *name) STUB_RETVAL(NULL)
