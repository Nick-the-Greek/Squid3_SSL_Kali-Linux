#ifndef SQUID_FS_MODULE_H
#define SQUID_FS_MODULE_H

namespace Fs
{

void Init();
void Clean();

} // namespace Fs

#endif /* SQUID_FS_MODULE_H */
